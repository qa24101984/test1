package com.mycompany.mavenprojectcamunda001;

import java.util.HashMap;
import java.util.Map;
import javax.sql.DataSource;
import org.camunda.bpm.engine.ProcessEngineConfiguration;
import org.camunda.bpm.engine.impl.cfg.ProcessEngineConfigurationImpl;
import org.camunda.bpm.engine.impl.event.EventHandler;
import org.camunda.bpm.engine.impl.event.EventType;
import org.camunda.bpm.engine.impl.history.HistoryLevel;
import org.camunda.bpm.engine.impl.interceptor.CommandContext;
import org.camunda.bpm.engine.impl.persistence.entity.EventSubscriptionEntity;
import org.camunda.bpm.engine.spring.SpringProcessEngineConfiguration;
import org.camunda.bpm.engine.spring.SpringProcessEngineServicesConfiguration;
import org.camunda.spin.plugin.impl.SpinProcessEnginePlugin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

@Configuration
@Import(SpringProcessEngineServicesConfiguration.class)
public class BaseConfiguration {
    
    @Autowired
    DataSource dataSource;
    
    @Autowired
    ResourcePatternResolver resourceLoader;
           
    @Bean
    public SpringProcessEngineConfiguration getSpringProcessEngineServicesConfiguration() throws Exception {
        SpringProcessEngineConfiguration config = new SpringProcessEngineConfiguration();
        
        config.setDataSource(dataSource);
        config.setDatabaseSchemaUpdate("true");
        
        //config.setMetricsEnabled(true);
        
        //ProcessEngineConfigurationImpl;
        
        //ProcessEngineConfigurationImpl;
        
        config.setTransactionManager(new DataSourceTransactionManager(dataSource));
        
        config.setHistoryLevel(HistoryLevel.HISTORY_LEVEL_FULL);
        
        config.setJobExecutorActivate(true);
        config.setMetricsEnabled(true);
        
        config.getProcessEnginePlugins().add(new SpinProcessEnginePlugin());
        
        Resource[] resources = resourceLoader.getResources("classpath:/*bpmn");
        config.setDeploymentResources(resources);
        
        return config;       
    }          
}

