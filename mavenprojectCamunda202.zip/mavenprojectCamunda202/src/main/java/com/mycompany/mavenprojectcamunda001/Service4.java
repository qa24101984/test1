package com.mycompany.mavenprojectcamunda001;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

@Component
public class Service4 implements JavaDelegate {
    @Override
    public void execute(DelegateExecution execution) throws Exception {
        System.out.println("-----------4-----------" + execution.getVariables());
        Thread.sleep(10000);
    } 
}
