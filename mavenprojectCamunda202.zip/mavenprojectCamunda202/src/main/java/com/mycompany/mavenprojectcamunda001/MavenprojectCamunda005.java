package com.mycompany.mavenprojectcamunda001;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.history.HistoricVariableInstance;
import org.camunda.bpm.engine.management.JobDefinition;
import org.camunda.bpm.engine.management.Metrics;
import org.camunda.bpm.engine.repository.ProcessDefinition;
import org.camunda.bpm.engine.runtime.ActivityInstance;
import org.camunda.bpm.engine.runtime.Execution;
import org.camunda.bpm.engine.runtime.Job;
import org.camunda.bpm.engine.runtime.ProcessInstance;
import org.camunda.bpm.engine.task.Task;
import org.camunda.bpm.engine.variable.Variables;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class MavenprojectCamunda005 {

    public static void main(String[] args) {      
        ApplicationContext ctx = SpringApplication.run(MavenprojectCamunda005.class);
        
        ProcessEngine eng = ctx.getBean(ProcessEngine.class);
        
        ProcessDefinition def
                = eng.getRepositoryService()
                        .createProcessDefinitionQuery()
                        .processDefinitionKey("process1")
                        .singleResult();
        
        Map<String, Object> map = new HashMap<String, Object>();
        List<String> listTasks = new LinkedList<String>();
        for (int i = 0; i < 100; i++) {
            listTasks.add("test" + i + "value");
        }
        map.put("taskList", listTasks);
        map.put("maxNrOfActiveTasks", 20);
        map.put("testCon", 0);
        map.put("nrOfActiveTasks", 0);
        map.put("curTask", 0);

        ProcessInstance processInstance = eng.getRuntimeService()
                .createProcessInstanceByKey("process1")
                .setVariables(map)
                .execute();
        
        try {
            Thread.sleep(5000);
        } catch (Exception ex) {
            System.out.println("-----------ERROR--------");
            ex.printStackTrace();
        }
        
        /*long v1 = eng.getManagementService()
                .createMetricsQuery()
                .name(Metrics.PROCESS_INSTANCES)
                .sum();
        
        List<ProcessInstance> taskList = eng.getRuntimeService()
                .createProcessInstanceQuery()
                .active()
                .list();
        
        List<Execution> execution = eng.getRuntimeService().createExecutionQuery().processInstanceId(processInstance.getId()).active().list();
        
        eng.getRuntimeService().setVariable(execution.get(0).getId(), "testCon", 15);
        
        List<Job> list = eng.getManagementService().createJobQuery().active().list();
        
        List<Job> list2 = eng.getManagementService().createJobQuery().suspended().list();
        
        List<Job> list3 = eng.getManagementService().createJobQuery().list();
        
        ActivityInstance activityInstance = 
                eng.getRuntimeService().getActivityInstance(processInstance.getId());*/

        System.out.println("-----------END------------");
    }
}
