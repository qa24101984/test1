package com.mycompany.mavenprojectcamunda001;

import java.util.List;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.camunda.bpm.engine.runtime.Job;
import org.springframework.stereotype.Component;

@Component
public class Service3 implements JavaDelegate {
    @Override
    public void execute(DelegateExecution execution) throws Exception {
        System.out.println("-----------3-----------" + execution.getVariables());
        
        List<Job> list = execution.getProcessEngine().getManagementService().createJobQuery().active().list();
        System.out.println("-----------3.1-----------" + list.size());
        
        //List list2 = execution.getProcessEngine().getRuntimeService().createProcessInstanceQuery().variableValueGreaterThan("loopCounter", 0).list();
        //System.out.println("-----------3.2-----------" + execution.getVariable("nrOfActiveInstances"));
    }   
}
