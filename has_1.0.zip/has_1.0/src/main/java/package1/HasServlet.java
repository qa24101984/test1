/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package package1;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.*;
import java.util.logging.Level;
import java.util.stream.Collectors;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.commons.digester3.Digester;
import org.xml.sax.SAXException;
import org.apache.commons.io.IOUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;

public class HasServlet extends HttpServlet {
    
    private static Logger logger = Logger.getLogger(HasServlet.class);

    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        response.setContentType("text/html");
        response.setCharacterEncoding("Cp1251");
        PrintWriter out = response.getWriter();
        ServletContext servletContext = request.getServletContext();

        String dir = null;
        String add = null;

        Properties prop = new Properties();
        InputStream inputStream = null;
        try {

            inputStream = servletContext.getResourceAsStream("/WEB-INF/classes/config.properties");

            prop.load(inputStream);

            dir = prop.getProperty("dirName");
            add = prop.getProperty("realAdd");

            inputStream.close();

        } catch (IOException ex) {
            if (inputStream != null) {
                inputStream.close();
            }
            throw ex;
        }

        if (dir == null) {
            out.println("Fail dirName");
            return;
        }
        if (add == null) {
            out.println("Fail realAdd");
            return;
        }

        String uri = servletContext.getRealPath("");
        File projectDir = new File(uri);
        File baseDir = projectDir.getParentFile();
        String pathDir = baseDir.getAbsolutePath();
        if (pathDir.contains("/")) {
            pathDir = pathDir + "/" + dir;
        } else {
            pathDir = pathDir + "\\" + dir;
        }

        baseDir = new File(pathDir);
        if (!baseDir.exists()) {
            baseDir.mkdirs();
        }

        String subDir = null;
        Map<String, String[]> params = request.getParameterMap();
        for (String param : params.keySet()) {
            if (param.equalsIgnoreCase("msisdn")) {
                subDir = params.get(param)[0];
            }
        }
        for (String param : params.keySet()) {
            if (param.equalsIgnoreCase("ms")) {
                subDir = params.get(param)[0];
            }
        }        
        if (subDir == null) {
            for (String param : params.keySet()) {
                if (param.equalsIgnoreCase("acc")) {
                    subDir = params.get(param)[0];
                }
            }
        }
        if (subDir == null) {
            for (String param : params.keySet()) {
                if (param.equalsIgnoreCase("okpo")) {
                    subDir = params.get(param)[0];
                }
            }
        }
        if (subDir == null) {
            for (String param : params.keySet()) {
                if (param.equalsIgnoreCase("subs")) {
                    subDir = params.get(param)[0];
                }
            }
        }
        if (subDir == null) {
            subDir = "other";
        }
        if (pathDir.contains("/")) {
            pathDir = pathDir + "/" + subDir;
        } else {
            pathDir = pathDir + "\\" + subDir;
        }
        baseDir = new File(pathDir);
        if (!baseDir.exists()) {
            baseDir.mkdirs();
        }

        String fileName = null;
        if (fileName == null) {
            for (String param : params.keySet()) {
                if (param.equalsIgnoreCase("action")) {
                    fileName = params.get(param)[0];
                }
            }
        }
        if (fileName == null) {
            String path = request.getPathInfo();
            if (path.endsWith("/")) {
                path = path.substring(0, path.length() - 1);
            }
            if (path.endsWith("\\")) {
                path = path.substring(0, path.length() - 1);
            }
            if (path.lastIndexOf("/") != -1) {
                path = path.substring(path.lastIndexOf("/") + 1, path.length());
            }
            if (path.lastIndexOf("\\") != -1) {
                path = path.substring(path.lastIndexOf("\\") + 1, path.length());
            }
            fileName = path;
        }

        BufferedWriter bw = null;
        try {
            if (pathDir.contains("/")) {
                pathDir = pathDir + "/";
            } else {
                pathDir = pathDir + "\\";
            }
            pathDir = pathDir + fileName;

            fileName = pathDir + ".xml";

            if (!(new File(fileName)).exists()) {
                
                logger.debug("Not found file " + fileName);
                
                String realPath = add + request.getPathInfo() + "?" + request.getQueryString();
                logger.debug("Load file " + realPath);
                URLConnection connection = new URL(realPath).openConnection();
                connection.setConnectTimeout(10000);
                connection.setReadTimeout(10000);
                String xml = IOUtils.toString(connection.getInputStream(), "Cp1251");
                out.println(xml + "\n");
                
                logger.debug("Write file " + fileName);
                bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileName), "Cp1251"));
                bw.write(xml);
                bw.close();

                /*bw = new BufferedWriter(new FileWriter(pathDir + "_request.xml"));
                bw.write(realPath);
                bw.close();*/
            } else {
                logger.error("Send file" + fileName);     

                StringBuilder sb = new StringBuilder();
                char[] buffer = new char[1024 * 4];
                int n = 0;
                
                FileInputStream fstream1 = new FileInputStream(fileName);
                DataInputStream in = new DataInputStream(fstream1);
                BufferedReader input = new BufferedReader(new InputStreamReader(in, "Cp1251"));
                while (-1 != (n = input.read(buffer))) {
                    sb.append(buffer, 0, n);
                }
                String xml = sb.toString();
                out.println(xml);
            }

        } catch (Exception e) {
            if (bw != null) {
                bw.close();
            }
            logger.error("Error ", e);
        }
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        doGet(request, response);
    }

}
